// Problem 4

/*
The single quotes surrounding `Hello`.  Single quotes are for char literals; one uses double quotes for strings.
*/

#include <iostream>
#include <string>

int main() {
	int x = 5;
	int y;
	double z = 4;
	std::string pq = 'Hello';
	std::cout << x << y << z << pq;		
}